<?php
session_start();
$host="localhost";
$user="root";
$password="";
$con=mysqli_connect($host,$user,$password,"sc_hackathon");
$message = "wrong credentials";

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$uname = $_POST['uname'];
            
            if (!empty($_POST['uname']) 
               && !empty($_POST['pwd'])) {
				
$sql = "SELECT password FROM sc_login where username='" . $_POST['uname'] . "'";

$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row 
	//$SESSION["user"] = $uname;
$row = mysqli_fetch_assoc($result);
//$SESSION["user"] = $uname;

	if($_POST['pwd'] == $row["password"])
	echo "<script>window.location.assign('/project/a.html'); </script>";
else
{
	        
             echo "<script type='text/javascript'>alert('$message');</script>";
			  echo "<script>window.location.assign('/project/sc_login.html'); </script>";
		   
} 
    }
else
echo 'Wrong Username';
}
$_SESSION['username'] = $_POST['uname'];  
              
                
        
                 
            
?>
